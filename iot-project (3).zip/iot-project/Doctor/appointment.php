<!DOCTYPE html>
<html>
<head>
	<title>Book Appointment</title>
</head>
<body>
<?php  
include("../login/header.php");
include("../login/connection.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2" style="margin-left: -30px">
			<?php  
			include("../Doctor/sidenav.php");
			?>
		</div>
		<div class="col-md-10">


				<?php 
						//$ad=$_SESSION['admin'];
						$query="SELECT * FROM doctor ";
					$res=mysqli_query($conn,$query);
					$output="
					
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>Username</th>
							<th style='width: 10%';>Action</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New Admin</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$username=$row['username'];
						$output.="
						<tr>
								<td>$id</td>
								<td>$username</td>
								<td>
								<form action='admin.php' method='POST'><button id='$id' class='btn btn-danger' name='remove'>Remove</button></form>
									
								</td>
						";
					}
					}
					?>

			<h5 class="text-center my-2">Book Appointment</h5>
			<?php 
			$query="SELECT * FROM `appointment` WHERE status='pending'";
			$res=mysqli_query($conn,$query);
			$output="";
			$output.="
			<table class='table table-bordered'>
			<tr>
			<td>ID</td>
			<td>First Name</td>
			<td>Surname</td>
			<td>Gender</td>
			<td>Phone</td>
			<td>Appointment</td>
			<td>Symptoms</td>
			<td>Date</td>
			<td>Action</td>
			</tr>
			</table>
			";
			/*if(mysql_num_rows($res)<1){
				$output.="<tr><td class='text-center' colspan'8'>No Appointment yet</td></tr>";

			}*/
			if(isset($_POST['book'])){
				//$pat=$_SESSION['patient']; 
				$sel=mysqli_query($conn,"SELECT * FROM patient");
				$row=mysqli_fetch_array($sel);
				$fname=$row['firstname'];
				$sname=$row['surname'];
				$gender=$row['gender'];
				$phone=$row['phone'];
				$date=$_POST['date'];
				$sym=$_POST['sym'];
				if(empty($sym)){

				}else{
					$query="INSERT INTO `appointment`(`id`, `firstname`, `surname`, `gender`, `appointment_date`, `symptoms`, `status`, `date_booked`,`phone`) VALUES ('','$fname','$sname','$gender','$date','$sym','pending','NOW()'$phone')";
					$res=mysqli_query($conn,$query);
					if($res){
						echo"<script>alert('you have booked an appointment')</script>";
					}
				}
			}
			while ($row=mysqli_fetch_array($res)) {
				$output.="
				<tr>
				<td>".$row['id']."</td>
				<td>".$row['firstname']."</td>
				<td>".$row['surname']."</td>
				<td>".$row['gender']."</td>
				<td>".$row['phone']."</td>
				<td>".$row['appointment_date']."</td>
				<td>".$row['symptoms']."</td>
				<td>".$row['date_booked']."</td>
				<td>
				<a href='discharge.php?id=".$row['id']."'>
				<button class='btn btn-info'>Check</button>
				</a></td>
				</tr>
				";
			}
			?>
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-3"></div>
						<div class="col-md-6 jumbotron">
							<form method="post">
								<label>Appointment Date</label>
								<input type="date" name="date" class="form-control" >
								<label>Symptoms</label>
								<input type="text" name="sym" class="form-control" autocomplete="off" placeholder="Enter the symptoms">
								<input type="submit" name="book" class="btn btn-info my-2" value="Book Appointment">
							</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>