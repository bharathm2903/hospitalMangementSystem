<!DOCTYPE html>
<html>
<head>
	<title>Discharge</title>
</head>
<body>
<?php 
include("../login/header.php");
include("../loginn/connection.php");
 ?>
 <div class="container-fluid">
 	<div class="col-md-12">
 		<div class="row">
 			<div class="col-md-2" style="margin-left: -30px">
 				<?php  
 					include("../patient/sidenav.php");
 				?>
 			</div>
 			<div class="col-md-10">
 				<h5 class="text-center">Total Appointment</h5>
 			</div>
 		</div>
 	</div>
 </div>
</body>
</html>