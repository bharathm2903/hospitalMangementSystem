<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php  
include("../login/header.php");

?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2 " style="margin-left: -30px;">
			<?php
				include("../Doctor/sidenav.php");
				include("../login/connection.php");

				if (isset($_POST['select_id'])) {
						$uname=$_POST['select_id'];
						 $p="DELETE FROM `patient` WHERE id='".$uname."'";// exit;
						$res1=mysqli_query($conn,$p);
					}
			  ?>
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h5 class="text-center">All Patient's</h5>
						<?php 
						$query="SELECT * FROM patient";
						$res=mysqli_query($conn,$query);
						$output="
					
					<form action='patient.php' id='patientForm' method='POST'>
					<input type='hidden' name='select_id' id='select_id'>
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>Username</th>
							<th style='width: 10%';>Action</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New Paient</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$username=$row['username'];
						$output.="

						<tr>
								<td>$id</td>
								<td>$username</td>
								<td>";
								$output.='
								<button class="btn btn-danger" onclick="removePatient('.$id.')" name="remove">Remove</button>
									
								</td>
						';
					}
					}
					$output.="<tr></tr>
						</table></form>";
					echo "$output";
					//print_r($_POST);
					

						?>



					</div>
					<div class="col-md-6">
						<?php
						include("../login/connection.php");
						if(isset($_POST['add'])){
							$uname=$_POST['uname'];
							$pass=$_POST['pass'];
							//$image=$_FILES['img']['name'];
							$error=array();
							if(empty($uname)){
								$error['u']="Enter Doctor Username";
							}
							else if(empty($pass)){
								$error['u']="Enter Doctor Password";
							}
							/*else if(empty($image)){
								$error['u']="Add Admin Picture";
							}*/
						//print_r($_FILES); exit;
							if(!empty($_FILES['img'])){
								move_uploaded_file($_FILES['img']['tmp_name'], "image/".$image);
								$imgName = $_FILES['img']['name'];
							}else{
								$imgName = "NULL";
							}
							

							$q="INSERT INTO `doctor`(`username`,`password`) VALUES('$uname','$pass')";
								$result=mysqli_query($conn,$q);
								if($result){
									
									header("Location:../doctor/doctor-1.php?success");
								}
								else{
								header("Location:../doctor/doctor-1.php?failed");
							}
						}
						?>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<script type="text/javascript">
	function removePatient(id){
		document.getElementById('select_id').value= id;
		document.getElementById("patientForm").submit();

	}
</script>
</body>
</html>