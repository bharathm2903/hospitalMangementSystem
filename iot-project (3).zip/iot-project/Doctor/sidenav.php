<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
				
				<!--sidenav-->
				<div class="list-group bg-info" style="height:90vh;width: 30vh ">
					<a href="../Doctor/index.php" class="list-group-item list-group-item-action bg-info text-center text-white">Dashboard</a>
					<a href="../Doctor/profile.php" class="list-group-item list-group-item-action bg-info text-center text-white">Profile</a>
					<a href="../Doctor/appointment.php" class="list-group-item list-group-item-action bg-info text-center text-white">Book Appointment</a>
					<a href="../Doctor/view-app.php" class="list-group-item list-group-item-action bg-info text-center text-white">Appointments</a>
					<a href="../Doctor/patient.php" class="list-group-item list-group-item-action bg-info text-center text-white">Patients</a>
				</div>

</body>
</html>