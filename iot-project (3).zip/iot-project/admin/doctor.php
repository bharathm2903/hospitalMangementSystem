<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2 " style="margin-left: -30px;">
			<?php
				include("../admin/sidenav.php");
				include("../login/connection.php");
				if (isset($_POST['select_id'])) {
						$uname=$_POST['select_id'];
						 $p="DELETE FROM `doctor` WHERE id='".$uname."'";// exit;
						$res1=mysqli_query($conn,$p);
					}
			  ?>
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h5 class="text-center">All Doctor's</h5>
						<?php 
						//$ad=$_SESSION['admin'];
						$query="SELECT * FROM doctor ";
					$res=mysqli_query($conn,$query);
					$output="
					
					<form action='doctor.php' id='patientForm' method='POST'>
					<input type='hidden' name='select_id' id='select_id'>
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>Username</th>
							<th style='width: 10%';>Action</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New Admin</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$username=$row['username'];
						$output.="

						<tr>
								<td>$id</td>
								<td>$username</td>
								<td>";
								$output.='
								<button class="btn btn-danger" onclick="removePatient('.$id.')" name="remove">Remove</button>
									
								</td>
						';
					}
					}
					$output.="<tr></tr>
						</table><form>";
					echo "$output";
					if (isset($_POST['remove'])) {
						$_SESSION['Doctor']=$uname;
						$p="DELETE FROM `doctor` WHERE username='$uname'";
						$res1=mysqli_query($conn,$p);
					}

						?>

					</div>
					<div class="col-md-6">
						<?php
						include("../login/connection.php");
						if(isset($_POST['add'])){
							$uname=$_POST['uname'];
							$pass=$_POST['pass'];
							//$image=$_FILES['img']['name'];
							$error=array();
							if(empty($uname)){
								$error['u']="Enter Doctor Username";
							}
							else if(empty($pass)){
								$error['u']="Enter Doctor Password";
							}
							/*else if(empty($image)){
								$error['u']="Add Admin Picture";
							}*/
						//print_r($_FILES); exit;
							if(!empty($_FILES['img'])){
								move_uploaded_file($_FILES['img']['tmp_name'], "image/".$image);
								$imgName = $_FILES['img']['name'];
							}else{
								$imgName = "NULL";
							}
							

							$q="INSERT INTO `doctor`(`username`,`password`) VALUES('$uname','$pass')";
								$result=mysqli_query($conn,$q);
								if($result){
									echo '<script>alert("successfully added")</script>';
									//header("Location:../admin/doctor.php");
								}
								else{
									echo '<script>alert("failed to add")</script>';
								//header("Location:../admin/doctor.php?failed");
							}
						}
						?>
						<h5 class="text-center">Add Doctor</h5>
						<form action="doctor-1.php" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<label>Username</label>
								<input type="text" name="uname" autocomplete="off">
							</div>
							<div class="form-group">
								<label>Password</label>
								<input type="password" name="pass" autocomplete="off">
							</div>
							<div class="form-group">
								<label>Add Admin Image </label>
								<input type="file" name="img" class="form-control">
							</div>
							<input type="submit" name="add" value="Add New Doctor
							" class="btn btn-success" style="size: 20px">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<script type="text/javascript">
	function removePatient(id){
		document.getElementById('select_id').value= id;
		document.getElementById("patientForm").submit();

	}
</script>
</body>
</html>