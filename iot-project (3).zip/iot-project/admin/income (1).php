<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Total Income</title>
</head>
<body>
	<?php
		include("../login/header.php");
		include("../login/connection.php");

	?>

	<div class="container-fluid">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-2" style="margin-left: -30px">
				<?php

				include("sidenav.php");
				?> 
				</div>
				<div class="col-md-10">
					<h5 class="text-center my-2">Total Income</h5>
			</div>
		</div>
	</div>

</body>
</html>