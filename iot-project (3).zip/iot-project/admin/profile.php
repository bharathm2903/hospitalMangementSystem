<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin Profile</title>
</head>
<body>
<?php  
include("../login/header.php");
include("../login/connection.php");
$ad=$_SESSION['admin'];
$query="SELECT * FROM admin WHERE username='$ad'";
$res=mysqli_query($conn,$query);
while ($row=mysqli_fetch_array($res)) {
	$username=$row['username'];
	$Profile=$row['profile'];
}
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-2" style="margin-left: -30px;">
				<?php
				 include("sidenav.php");
				?>
			</div>
			<div class="col-md-10">
				<div class="col-md-12">
					<div class="row">
						<div class="col-md-6">
							<h4><?php echo $username;?> Profile</h4>

							<?php  
							if(isset($_POST['update'])){
								$profile=$_FILES['profile']['name'];
								if(empty($profile)){

								}
								else{
									$query="UPDATE admin SET profile ='$profile' WHERE username='$ad'";

									$result=mysqli_query($conn,$query);
									if($result){
										move_uploaded_file($_FILES['profile']['tmp_name'],$image/image);
									}
								}
							}
							?> 
							<form method="POST" enctype="multipart/form-data ">
								<?php
							echo "<img src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQG5yZYmGtEkcsIbaofHrkRo2OrhUt7KoGwnw&usqp=CAU' class='col-md-12'  style='height: 200px; width:150px'>";
							?>
							<br><br>
							<div class="form-group">
								<label>Update Profile</label>
								<input type="file" name="profile" class="form-control">
							</div>
							<br>
							<input type="submit" name="update" value="UPDATE" class="btn btn-success">	
							</form>
							<div class="col-md-6"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>