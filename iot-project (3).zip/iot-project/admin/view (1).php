<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>View Patient Details</title>
</head>
<body>
	<?php
		include("../login/header.php");
		include("../login/connection.php");

	?>

	<div class="container-fluid">
		<div class="col-md-12">
			<div class="row">
				<div class="col-md-2" style="margin-left: : -30px;">
					<?php
						include("sidenav.php");
					?>
				</div>
				<div class="col-md-10">
					<h5 class="text-center my-3">View Patient Details</h5>

					<?php
 
						//$ad=$_SESSION['admin'];
						$query="SELECT * FROM patient ";
					$res=mysqli_query($conn,$query);
					$output="
					
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>Username</th>
							<th style='width: 10%';>Action</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New patient</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$username=$row['username'];
						$output.="
						<tr>
								<td>$id</td>
								<td>$username</td>
								<td>
								<form action='admin.php' method='POST'><button id='$id' class='btn btn-danger' name='remove'>Removes</button></form>
									
								</td>
						";
					}
					}
					$output.="<tr></tr>
						</table>";
					echo "$output";
					if (isset($_POST['remove'])) {
						$p="DELETE FROM `patient` WHERE `id`='$id'";
						$res1=mysqli_query($conn,$p);
					}

						?>
					<div class="col-md-12">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6">

								<table class="table table-boardered">
									<?php  $query = "SELECT * FROM patient";
									$res = mysqli_query($conn,$query);
								while ($row= mysqli_fetch_array($res)){
					  		    $output .="
					  			<tr>
					  				<td>".$row['firstname']."</td>
					  				<td>".$row['surname']."</td>
					  				<td>".$row['email']."</td>
					  				<td>".$row['username']."</td>
					  			</tr>
					  		";
					  	}
					?>
				</div>
			</div>
		</div>
	</div>

</body>
</html>