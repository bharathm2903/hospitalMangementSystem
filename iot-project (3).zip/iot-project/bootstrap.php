<!DOCTYPE html>
<html>
<head>
	<title>BootStrap</title>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.js" integrity="sha256-DrT5NfxfbHvMHux31Lkhxg42LY6of8TaYyK50jnxRnM=" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand  text-info" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon navbar-info"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link text-info" href="#" >Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link  text-info" href="#">Link</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled  text-info" href="#">Disabled</a>
      </li>
    </ul>

  </nav>
  </div>
</nav>
<div class="container">
<h1 class="page-header">Hello hi how are you good to see yous<small>bharath is here</small></h1>
<!--paragraph property-->
<p class="lead">
	Recently, a small village,<del>in Tamilnadu where only</del>  male shepherd reside with four sheep each, was devastated by Tsunami waves. Therefore 8 persons and <mark>47 sheep were found to</mark> be dead and the person who luckily survived, left the village with one sheep each since 21 sheep were too injured to move so <u>have left on their on luck</u>, in the village. The number of sheep which were earlier in the village was :
</p>
<hr>
<!--text transformation-->
<p class="text-center">bharath is good boy</p>
<p class="text-right">he is always watching shinchan</p>
<p class="text-left text-uppercase">he like to play cricket</p>
<p class="text-capitalize">he wanna to place in good company</p>
</div>
<div class="pull-right">div right</div>
<hr>
<!--blockquote-->
<blockquote class="blockquote">
	<p>hi hello how are you powered by bharath nickom limited</p>
	<footer>designed by<cite title="bharath">bharath</cite></footer>
	<kbd>hello</kbd>
	<!--for red highlight-->
	<code>&it;&gt;hi bharath&it;&gt;</code>
</blockquote>
<p class="text-muted">bharath is good boy</p>
<p class="text-success">he is always watching shinchan</p>
<p class="text-info">he like to play cricket</p>
<p class="text-warning">he wanna to place in good company</p>

<hr>

<p class="bg-secondory">bharath is good boy</p>
<p class="bg-success">he is always watching shinchan</p>
<p class="bg-info">he like to play cricket</p>
<p class="bg-warning">he wanna to place in good company</p>

<hr>

<button class="btn btn-default">Default</button>
<button class="btn btn-success">Default</button>
<button class="btn btn-warning">Default</button>
<button class="btn btn-info">Default</button>
<br>
<a href="#" class="btn btn-warning" role="button">Link</a>
<input type="button" name="login" value="submit" class="btn btn-info">
<br>
<!--contectual button-->
<button class="btn btn btn-success btn-lg">Login to hms</button>
<button class="btn btn btn-info btn-default">Login</button>
<button class="btn btn btn-warning btn-sm">Login</button>
<br>
<button class="btn btn btn-primary btn-xs">Login to HMS</button>
<hr>
<div class="container">
	<div class="jumbotron">
	<form class="form-group">
		<div class="form-group">
			<label>Name</label>
			<input type="text" name="uname" class="form-control" placeholder="enter ur name">
		</div>
		<div class="form-group">
			<label>Password</label>
			<input type="text" name="uname" class="form-control">
		</div>
		<div class="form-group">
			<label>Gender</label>
			<select class="form-control">
				<option>Male</option>
				<option>Female</option>
				<option>others</option>
			</select>
		</div>
		<div class="form-group">
			<label>Upload File</label>
			<input type="file" name="img">
			<p >only png is accepted</p>
		</div>
		<div class="checkbox">
			<label>
				<input type="checkbox" name="chk">male
			</label>
<br>
			<label>
				<input type="checkbox" name="chk">female
			</label>
		</div>
		<div class="checkbox">
			<label>Remember me<input type="checkbox" name="chk"></label>
			<br>
			<kbd>this page redirect you to index  </kbd>
			<br>
			<code>&it;&gt;this page redirect you to index  &it;&gt;</code>
			<button class="btn btn-primary">Login</button>

		</div>
	</form>
</div>
</div>

<div class="container">
	<table class="table table-striped table-bordered table-hover table-condensed">
		<tr>
			<th>Fisrt name</th>
			<th>Surname</th>
			<th>Age</th>
		</tr>
		<tr>
			<td>bharath_2903</td>
			<td>M</td>
			<td>20</td>
		</tr>
		<tr>
			<td>bharath_07</td>
			<td>M</td>
			<td>20</td>
		</tr>
		<tr>
			<td>bharath</td>
			<td>M</td>
			<td>20</td>
		</tr>
	</table>
</div>

<div class="container">
	<div class="list-group">
		<ul>
			<li class="list-group-item">23</li>
			<li class="list-group-item">231</li>
			<li class="list-group-item">345</li>
		</ul>
	</div>
	<div class="list-group">
		<ul>
			<a href="#" class="list-group-item active">123</a>
			<a href="#" class="list-group-item list-group-item-warning">123</a>
			<a href="#" class="list-group-item list-group-item-default">123</a>
			<a href="#" class="list-group-item list-group-item-success">123</a>
		</ul>
	</div>
</div>
<div class="container">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<div class="panel-title
			">
				panel title
			</div>
		</div>
		<div class="panel-body">
			panrl con
		</div>


	</div>
<div class="well">bharath</div>
</div>


<div class="alert alert-success ">you successfully loged in</div>
<div class="alert alert-warning alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert active"><span>&times;</span></button>hi all of u</div>
	<div class="alert alert-warning alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>Warning!</strong> Better check yourself, you're not looking too good.
</div>
<div class="container">
<div class="progress">
	<div class="progress-bar progress-bar-success progress-bar-striped active" style="width: 60%">60%
		
	</div>
</div>
<div class="panel panel-success">
  <div class="panel-body">
    Basic panel example
  </div>
</div>
<span class="label label-info">click</span>
<span class="label label-default">Default</span>
<span class="label label-primary">Primary</span>
<span class="label label-success">Success</span>
<span class="badge">Info</span>
<span class="label label-warning">Warning</span>
<span class="label label-danger">Danger</span>
</div>

<div class="container">
	<div class="row">
		<div class="col md-4">
			<p>The fixed navbar will overlay your other content, unless you add padding to the top of the. Try out your own values or use our snippet below. Tip: By default, the navbar is 50px high.</p>
		</div>
		<div class="col md-4">
			<p>The fixed navbar will overlay your other content, unless you add padding <mark>to the top of the. Try out your own values or use </mark>our snippet below. Tip: By default, the navbar is 50px high.</p>
		</div>
		<div class="col md-4">
			<p>The fixed navbar will overlay your other content, unless you add padding to the top of the. Try out your own values or use our snippet below. Tip: By default, the navbar is 50px high.</p>
		</div>
	</div>
</div>

<div class="container" style="height: 400px"></div>
</body>
</html>