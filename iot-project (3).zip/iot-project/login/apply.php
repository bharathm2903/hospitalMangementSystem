<!DOCTYPE html>
<html>
<head>
	<title>Apply Now.</title>
</head>
<body>
	<?php  
	include("../login/header.php");
	include("../login/connection.php");
	?>
	<div style="margin-top: 80px"></div>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6 jumbotron">
				<div class="alert alert-success">
					<?php
						if(isset($_POST['login'])){
							$user=$_POST['uname'];
							$pass=$_POST['pass'];
							$phone=$_POST['phone'];
							$email=$_POST['email'];

							$sql="INSERT INTO `doctor`( `username`, `password`,`phone`,`email`) VALUES ('$user','$pass','$phone','$email')";
    						$res=mysqli_query($conn,$sql);
    						if($res){
	 							echo "success";
    						}else {
	  							die("database connection failed");
    						}
						}
					?>
				</div>
				<form action="" method="post" class="my-2">
				<div class="text-center" style="font-size: 30px">Apply Now</div>
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="uname" class="form-control" autocomplete="off" placeholder="Enter Username">
				</div>
				<div class="form-group">
					<label>Surname</label>
					<input type="text" name="sname" class="form-control" autocomplete="off" placeholder="Enter Surname">
				</div>
				<div class="form-group">
					<label>E-mail</label>
					<input type="text" name="email" class="form-control" autocomplete="off" placeholder="Enter E-mail">
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password">
				</div>
				<div class="form-group">
					<label>Phone</label>
					<input type="number" name="phone" class="form-control" autocomplete="off" placeholder="Enter Phone">
				</div>
				<div class="form-group">
					<a href="#"></a>
				<input type="submit" name="login" class="btn btn-success" value="Apply Now">
				<p><b><a href="doctorlogin.php"> I already have an account</a></b></p>
			</div>
			</form>
		</div>
		<div class="col-md-3"></div>
	</div>
	</div>
</div>
</body>
</html>