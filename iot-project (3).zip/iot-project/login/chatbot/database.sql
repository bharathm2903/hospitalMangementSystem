
CREATE TABLE `chatbot_hints` (
  `id` int(11) NOT NULL,
  `question` varchar(100) NOT NULL,
  `reply` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chatbot_hints`
--

INSERT INTO `chatbot_hints` (`id`, `question`, `reply`) VALUES
(1, 'HI||Hello||Hola', 'Hello, how are you.'),
(2, 'How are you', 'Good to see you again!'),
(3, 'what is your name||whats your name', 'My name is Hospital Bot'),
(4, 'what should I call you', 'You can call me Vishal Bot'),
(5, 'Where are your from', 'I m from India'),
(6, 'Bye||See you later||Have a Good Day', 'Sad to see you are going. Have a nice day');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `added_on` datetime NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `message`, `added_on`, `type`) VALUES
(1, 'Hi', '2020-03-19 12:41:04', 'user'),
(2, 'Hello, how are you.', '2020-03-19 12:41:04', 'bot'),
(3, 'what is your name', '2020-03-19 12:41:04', 'user'),
(4, 'My name is Hospital Bot', '2020-03-19 12:41:04', 'bot'),
(5, 'Where are your from', '2020-03-19 12:41:04', 'user'),
(6, 'I m from India','2020-03-19 12:41:04', 'bot'),
(7, 'Go to hell', '2020-03-19 12:41:04', 'user'),
(8, 'Sorry not be able to understand you', '2020-03-19 12:41:04', 'bot'),
(9, 'bye|| thank you', '2020-03-19 12:41:04', 'user'),
(10, 'Sad to see you are going. Have a nice day','2020-03-19 12:41:04', 'bot');
(11, 'I had some health issue', '2020-03-19 12:41:04', 'user'),
(12, 'Type your issues here.', '2020-03-19 12:41:04', 'bot'),
(13, 'Fever || headache || snewsing || cold','2020-03-19 12:41:04', 'user'),
(14, 'I listed some medicine below Paracetamol,acetaminophen,Tylenol,aspirin.for cold cuff-D. Take anyone of the medicine the problem will continue
again come to Hospital', '2020-03-19 12:41:04', 'bot'),
(15, 'stomach ache || stomach problem || loose motion || hernia || Diarrhea', '2020-03-19 12:41:04', 'user'),
(16, 'I listed some medicine below atropine/diphenoxylate,Lomotil,loperamide,Florastor,gelusel-mps. Take anyone of the medicine the problem will continue
again come to Hospital', '2020-03-19 12:41:04', 'bot'),
(17, ' Arthritis Knee Pain,Rheumatoid arthritis,leg pain','2020-03-19 12:41:04', 'user'),
(18, 'I listed some medicine below paracetamol or a combination of paracetamol and codeine,Artho Sure Juice,Fast&Up Magnesio Magnesium & Zinc. Take anyone of the medicine the problem will continue
again come to Hospital','2020-03-19 12:41:04', 'bot'),
(19, 'sugar||diabetes','2020-03-19 12:41:04', 'user'),
(20, 'I listed some medicine below glimepiride (Amaryl)
glimepiride-pioglitazone (Duetact)
glimepiride-rosiglitazone (Avandaryl)
gliclazide.
glipizide (Glucotrol)
glipizide-metformin (Metaglip)
glyburide (DiaBeta, Glynase, Micronase)
glyburide-metformin (Glucovance).Take anyone of the medicine the problem will continue
again come to Hospital', '2020-03-19 12:41:04', 'bot');
(21, 'Blood Pressure || BP || Pressure','2020-03-19 12:41:04', 'user'),
(22, 'I listed some medicine below enalapril (Vasotec)
captopril (Capoten)
lisinopril (Zestril and Prinivil)
benazepril (Lotensin)
quinapril (Accupril)
perindopril (Aceon)
ramipril (Altace)
trandolapril (Mavik)  Take anyone of the medicine the problem will continue
again come to Hospital', '2020-03-19 12:41:04', 'bot'),
(23, 'Hearing lossses || Hearing problem || Eye problem', '2020-03-19 12:41:04', 'user'),
(24, 'Your application will be booked ASAP contact hospital number get your token for further medical proecss CALL:9876543210 PHONE:044-123456', '2020-03-19 12:41:04', 'bot'),
(25, 'Obesity || Weight problem','2020-03-19 12:41:04', 'user'),
(26, 'Try to avoid more sleep.Taking some physio excersice daily one book available in our hospital try to get or else you wamt to go with medicine Orlistat NIH external link (Xenical),Lorcaserin NIH external link (Belviq),Phentermine-topiramate NIH external link (Qsymia)(Adults),', '2020-04-22 12:41:30', 'bot'),
(27, 'I want fullcheck-up','2020-03-19 12:41:04', 'user'),
(28, 'Your appointment will be booked ASAP contact hospital to get further info CALL:9876543210 PHONE:044-123456','2020-03-19 12:41:04', 'bot'),
(29, 'How can i contact you || contact details', '2020-03-19 12:41:04', 'user'),
(30, 'I list out my contact info kindly use my helpline number to get more info: CALL:9876543210 PHONE:044-123456', '2020-03-19 12:41:04', 'bot');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chatbot_hints`
--
ALTER TABLE `chatbot_hints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chatbot_hints`
--
ALTER TABLE `chatbot_hints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
