<?php  
$dbHost="localhost";
$dbUser="root";
$dbPass="";
$dbName="hms";

$conn=mysqli_connect($dbHost,$dbUser,$dbPass,$dbName);
/*if($conn){
	echo "connected successfully";
}
else{
	echo "connection Failed";
}*/
?>
