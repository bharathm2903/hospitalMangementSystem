<!DOCTYPE html>
<html>
<head>
	<title>Doctor's Login Page</title>
</head>
<body>
<?php  
session_start();
?>
<?php  
include("../login/header.php");
?>
<?php  
include("../login/connection.php");
?>
<!DOCTYPE html>
<?php  
if(isset($_POST['login'])){
	$uname=$_POST['uname'];
	$password=$_POST['pass'];
	if (empty($uname)) {
		echo "<script>alert('Enter Username')</script>";
	}
	elseif (empty($password)) {
		echo "<script>alert('Enter password')</script>";
	}
	else if(!empty($uname) && !empty($password)){
		$query="SELECT * FROM doctor WHERE username='$uname' AND password='$password'";
		$res=mysqli_query($conn,$query);
		if(mysqli_num_rows($res)==1){
			$_SESSION['Doctor']=$uname;
			echo "<script>alert('hi you login as doctor')</script>";
			header("Location:../Doctor/index.php");
			exit(); 
		}else{
			echo "<script>alert('Invalid credintials')</script>";
		}
	}
}
?>
<div style="margin-top: 80px"></div>
<div class="container">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6 jumbotron">
			<form action="" method="post" class="my-2">
				<div class="text-center" style="font-size: 30px">Doctor Login</div>
				<div class="form-group">
					<label>Username</label>
					<input type="text" name="uname" class="form-control" autocomplete="off" placeholder="Enter Username">
				</div>
				<div class="form-group">
					<label>Password</label>
					<input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password">
				</div>
				<div class="form-group">
					<a href="#"></a>
				<input type="submit" name="login" class="btn btn-success" value="Login">
<p>I don't have an account <a href="apply.php"><b>Apply Now.</b></a></p>
			</div>
			</form>
		</div>
		<div class="col-md-3"></div>
	</div>
	</div>
</div>
</body>
</html>