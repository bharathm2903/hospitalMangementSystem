<!DOCTYPE html>
<html>
<head>
	<title>Hospital Management System</title>
	<link rel="stylesheet" type="text/css" href="https://www.codechef.com/APRIL21Chttps://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.js" integrity="sha256-DrT5NfxfbHvMHux31Lkhxg42LY6of8TaYyK50jnxRnM=" crossorigin="anonymous"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"></script>
</head>
<body>
<?php
include("../login/header.php");
?>

<div style="margin-top: 50px"></div>
<div class="container">
	<div class="col-md-12">
	<div class="row">
		<div class="col-md-3 mx-1 shadow">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXf58lQ-EGUAm-AzN4iXx0kZk5mWY9U0p6Ww&usqp=CAU">
			<h5 class="text-center"><b>More Info</b></h5><a href="#">
			<button class="btn btn-success my-3" style="margin-left: 30%" >Click To View</button></a>
		</div>
		<div class="col-md-4 mx-1 shadow">
			<img src="../image/patient.jpg" style="width: 100%">
			<h5 class="text-center"><b>Patient</b></h5>
			<h5 class="text-center">Create account here so that we can take good care for you.</h5><a href="patientlogin.php">
			<button class="btn btn-success my-3" style="margin-left: 30%" >Create Account</button></a>
		</div>
		<div class="col-md-4 mx-1 shadow">
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRX79Yavso5xa0g6Qr7PWFm28cfgH5gA6XwEg&usqp=CAU" style="width: 100%">
			<h5 class="text-center"><b>Doctor-Details</b></h5>
			<a href="../Doctor/doctor-1.php">
			<button class="btn btn-success my-3" style="margin-left: 30%" >Click To View</button></a>
		</div>
		<div class="p-3 border bg-light" style="margin-left: 35%">
			<img src="../image/pre.jpg" style="width:100%">
			<h5 class="text-center"><b>Analysis View</b></h5><a href="../image/IOT_project.pdf">
			<button class="btn btn-success my-3 mx-3" style="margin-left: 30%" >Click To View</button></a>
		</div>
	</div>
</div>
</div>
</body>
</html>
