<!DOCTYPE html>
<html>
<head>
	<title>Logout</title>
</head>
<body>
<div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
			<div class="col-md-6">
			<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h1 class="text-center-blue" style="font-size: 50px; color: #992966; text-shadow: 10px ;text-align: center">Thanks For Using Online Portal</h1>
			        </div>
			        <style >
			        	body{
			        		background:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSESpAJCTxtJhntBWm6yyJa3MMnN8dGxXPW-w&usqp=CAU);
			        		background-position: center;
			        		background-repeat: no-repeat;
			        		background-size:100vh;
			        		margin-bottom: 50%; 
			        	}
			        	.btn{
			        		background-color:  #992966;
			        		color: white;
			        		border-radius: 4px;
			        	}
			        </style>
			        <form action="../login/index.php" method="post">
			        <button class="btn" name="log">Login</button>
		            </form>
		         	<?php  
		         	if(isset($_POST['log'])){
		         		header("Location:../login/index.php");
		         	}
		         	?>
		            </div>
		            
	            </div>
            </div>
        </div>
	</div>
</div>
</div>
</body>
</html>