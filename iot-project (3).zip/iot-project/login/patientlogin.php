<?php  
session_start();
?>
<?php  
include("../login/header.php");
?>
<?php  
include("../login/connection.php");
?>
<!DOCTYPE html>
<?php  
if(isset($_POST['login'])){
	$uname=$_POST['uname'];
	$password=$_POST['pass'];
	if (empty($uname)) {
		echo "<script>alert('Enter Username')</script>";
	}
	elseif (empty($password)) {
		echo "<script>alert('Enter password')</script>";
	}
	else if(!empty($uname) && !empty($password)){
		$query="SELECT * FROM patient WHERE username='$uname' AND password='$password'";
		$res=mysqli_query($conn,$query);
		if(mysqli_num_rows($res)==1){
			$_SESSION['patient']=$uname;
			echo "<script>alert('hi you login as admin')</script>";
			header("Location:../patient/index.php");
			exit(); 
		}else{
			echo "<script>alert('Invalid credintials')</script>";
		}
	}
}
?>
<html>
<head>
	<title>Patient Login Page</title>
</head>
<body>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Patient Login</h5>
				 <form action="" method="POST">
				 	<div class="form-group">
				 		<label>Username</label>
				 		<input type="text" name="uname" class="form-control" autocomplete="off" placeholder="Enter Username">
				 	</div>
				 	<div class="form-group">
				 		<label>Password</label>
				 		<input type="password" name="pass" class="form-control" autocomplete="off" placeholder="Enter Password">
				 	</div>
				 	<input type="submit" name="login" class="btn btn-success my-3" value="Login">
				 	<a href="../patient/index.php">.</a>
				 	<p><b>I dont have an account </b><a href="account.php" >Click here.</a></p>
				 </form>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>
</body>
</html>
