<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Patient Dashboard</title>
</head>
<body>
<?php  
include("../login/header.php");
include("../login/connection.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-2" style="margin-left: -20px">
				<?php 
				include("sidenav.php"); 
				?>
			</div>
			<div class="col-md-10">
				 <h4 class="my-2">Patient Dashboard</h4>
				<div class="col-md-12 my-1">
					<div class="row">
						<div class="col-md-3 bg-success mx-2" style="height: 130px">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-8">
										<h5 class="text-white">My</h5> <h5 class="text-white">Profile</h5>
									</div>
									<div class="col-md-4">
										<a href="profile.php"><i class="fa fa-user-circle fa-3x  my-4" style="color: white"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 bg-warning mx-2" style="height: 130px">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-8">
										<h5 class="text-white">Book</h5> <h5 class="text-white">Appointment</h5>
									</div>
									<div class="col-md-4">
										<a href="appointment.php"><i class="fa fa-calendar fa-3x  my-4" style="color: white"></i></a>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3 bg-info mx-2" style="height: 130px">
							<div class="col-md-12">
								<div class="row">
									<div class="col-md-8">
										<h5 class="text-white">My</h5> <h5 class="text-white">Invoice</h5>
									</div>
									<div class="col-md-4">
										<a href="../patient/invoice.php"><i class="fas fa-file-invoice-dollar fa-3x  my-4" style="color: white"></i></a>
									</div>
								</div>
							</div>
						</div>

						<?php 
						if (isset($_POST['send'])){

    						$title = $_POST['send'];
    						$message = $_POST['message'];

    						$_SESSION['patient']='patient';
    						$user='patient';

    						$query = "INSERT INTO `report`(`id`, `title`, `message`, `username`, `date_send`) VALUES ('','$title','$message',$user,NOW())";

    						$res = mysqli_query($conn,$query);

    						if ($res) {

    							echo "<script>alert('You have sent Your Report')</script>";
    					}else{
    						echo "<script>alert('You haven't sent Your Report')</script>"; 
    					}


    				}
						?>

						<div class="col-md-12">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6 jumbotron  my-10">
								<h5 class="text-center my-2">Send A Report</h5>
								<form method="post">
									<label><b>Title</b></label>
									<input type="text" name="title" autocomplete="off" class="form-control" placeholder="Enter Title of the report">

									<label><b>Message</b></label>
									<input type="text" name="message" autocomplete="off" class="form-control" placeholder="Enter Message">

									<input type="submit" name="send" value="Send Report" class="btn btn-success my-2">
								</form>
							</div>
							<div class="col-md-3"></div>
						</div>
					</div>


					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
</body>
</html>