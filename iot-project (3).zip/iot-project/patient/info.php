<!DOCTYPE html>
<html>
<head>
  <title>Patient information</title>
</head>
<body>
  <?php  
include("../login/header.php");
  ?>
<div class="container-fluid">
  <div class="col-md-12">
    <div class="row">
      <div class="col-md-3"></div>
      <div class="col-md-6  jumbotron">
         <h5 class="text-center">Patient Information</h5>
         <form action="../patient/index.php" method="post">
          <div class="form-group">
            <label>Name</label>
            <input type="text" name="uname" class="form-control" autocomplete="off" placeholder="Enter Name">
          </div>
          <div class="form-group">
            <label>Age</label>
            <input type="number" name="age" class="form-control" autocomplete="off" placeholder="Enter Age">
          </div>
           <div class="form-group">
            <label>Date</label>
            <input type="date" name="time" class="form-control" autocomplete="off">
          </div>
          <div class="form-group">
            <label>Weight</label>
            <input type="number" name="weight" class="form-control" autocomplete="off" placeholder="Enter Weight">
          </div>
          <div class="form-group">
            <label>Height</label>
            <input type="number" name="height" class="form-control" autocomplete="off" placeholder="Enter Height">
          </div>
            <div class="form-group">
            <label>History of cancer in family</label>
            <select name="cancer" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Death(postmodom)</label>
            <select name="death" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Pregnent</label>
            <select name="preg" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Covid</label>
            <select name="covid" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Alcoholism</label>
            <select name="alco" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Headache</label>
            <select name="head" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Food poisoning</label>
            <select name="food" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Dental abscess</label>
            <select name="dental" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Thrombosis</label>
            <select name="thro" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Cough</label>
            <select name="cough" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Coma</label>
            <select name="coma" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Cirrhosis</label>
            <select name="cirrho" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Syphilis</label>
            <select name="syphi" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Rheumatoid</label>
            <select name="rhe" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Rabies</label>
            <select name="rab" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Maleria</label>
            <select name="maleria" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Kidney stone</label>
            <select name="stone" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Appendicities</label>
            <select name="app" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Leukemia</label>
            <select name="leuk" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>jaundice</label>
            <select name="jan" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Herpes</label>
            <select name="herpes" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Genitical candidiasis</label>
            <select name="gen" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Gonorrhoea</label>
            <select name="gono" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Diphtheria</label>
            <select name="dip" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Depression</label>
            <select name="dep" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Alzhemier's disease</label>
            <select name="alz" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Cholera</label>
            <select name="cholera" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>chikunguniya</label>
            <select name="chick" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Ulcer</label>
            <select name="ulcer" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Smoking or tobacco</label>
            <select name="smoking" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Anaemia</label>
            <select name="anaemia" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Diabetes</label>
            <select name="diabetes" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Heart Disease</label>
            <select name="heart" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Kidney Failure</label>
            <select name="kidney" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Hebatities</label>
            <select name="heb" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Asthma</label>
            <select name="asthma" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Chronic disease</label>
            <select name="chronic" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Tuberculosis</label>
            <select name="Tb" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Lipid disorder</label>
            <select name="Lipid" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Patch</label>
            <select name="patch" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Snewsing</label>
            <select name="snew" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Growth in mouth</label>
            <select name="mouth" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Fever</label>
            <select name="fever" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Cold</label>
            <select name="cold" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Obesity</label>
            <select name="obe" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Hyper tension</label>
            <select name="hyper" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>HIV</label>
            <select name="hiv" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Injury or violence</label>
            <select name="injury" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Mendal health</label>
            <select name="mhealth" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Flu or pneumonia</label>
            <select name="flu" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Suicide</label>
            <select name="suicide" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Accident</label>
            <select name="accident" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
           <div class="form-group">
            <label>Cataract</label>
            <select name="cat" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Skin disease</label>
            <select name="skin" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <div class="form-group">
            <label>Congential abnormalities</label>
            <select name="genitic" class="form-control">
              <option value="Male">NO</option>
              <option value="Female">YES</option>
            </select>
          </div>
          <input type="submit" name="login" class="btn btn-success my-3" value="Login">
          <a href="../patient/index.php">.</a>
          <p><b>I dont have an account </b><a href="account.php" >Click here.</a></p>
         </form>
      </div>
      <div class="col-md-3"></div>
    </div>
  </div>
</div>
</body>
</html>