<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Invoice</title>

</head>
<?php  


include("../login/header.php");

include("../login/connection.php");

?>
<body>
<?php 
						if (isset($_POST['send'])){

    						$title = $_POST['send'];
    						$message = $_POST['message'];

    						
    						$user=$_SESSION['patient'];

    						$query = "INSERT INTO `report`(`id`, `title`, `message`, `username`, `date_send`) VALUES ('','$title','$message','$user',NOW())";

    						$res = mysqli_query($conn,$query);

    						if ($res) {

    							echo "<script>alert('You have sent Your Report')</script>";
    							header("Location:../patient/index.php");
    					}else{
    						echo "<script>alert('You haven't sent Your Report')</script>"; 
    					}


    				}
						?>

						<div class="col-md-12">
						<div class="row">
							<div class="col-md-3"></div>
							<div class="col-md-6 jumbotron  my-10">
								<h5 class="text-center my-2">Send A Report</h5>
								<form method="post">
									<label><b>Title</b></label>
									<input type="text" name="title" autocomplete="off" class="form-control" placeholder="Enter Title of the report">

									<label><b>Message</b></label>
									<input type="text" name="message" autocomplete="off" class="form-control" placeholder="Enter Message">

									<input type="submit" name="send" value="Send Report" class="btn btn-success my-2">
								</form>
							</div>
							<div class="col-md-3"></div>
						</div>
					</div>
</body>
</html>