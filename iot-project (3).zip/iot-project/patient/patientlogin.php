<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2 " style="margin-left: -30px;">
			<?php
				include("sidenav.php");
				include("../login/connection.php");
			  ?>
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h5 class="text-center">All Patient</h5>
						<?php 
						$_SESSION['patient']='patient';  
						$ad='patient';
						$query="SELECT * FROM patient";
					$res=mysqli_query($conn,$query);
					$output="
					
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>Username</th>
							<th>Firstname</th>
							<th>Surname</th>
							<th>Gender</th>
							<th>Phone</th>
							<th>Date_Booked</th>
							<th style='width: 10%';>Action</th>
					</tr>";
					if(mysqli_num_rows($res)<1){
						$output.="<tr><td colspan='2'   class=text-center >No New Patient</td></tr>";
					}
					else{
					while ($row=mysqli_fetch_assoc($res)) {
						$id=$row['id'];
						$username=$row['username'];
						$firstname=$row['firstname'];
						$surname=$row['surname'];
						$gender=$row['gender'];
						$phone=$row['phone'];
						$date=$row['date_reg'];
						$output.="
						<tr>
								<td>$id</td>
								<td>$username</td>
								<td>$firstname</td>
								<td>$surname</td>
								<td>$gender</td>
								<td>$phone</td>
								<td>$date</td>
								<td>
								<form action='admin.php' method='POST'><button id='$id' class='btn btn-danger' name='remove'>Remove</button></form>
									
								</td>
						";
					}
					}
					$output.="<tr></tr>
						</table>";
					echo "$output";
					if (isset($_POST['remove'])) {
						$p="DELETE FROM `admin` WHERE `id`='$id'";
						$res1=mysqli_query($conn,$p);
					}
						?>

					</div>
					<div class="col-md-6">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>