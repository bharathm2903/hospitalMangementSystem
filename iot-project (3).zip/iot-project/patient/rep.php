<?php  
session_start();
?>
<?php  
include("../login/header.php");
?>
<?php  
include("../login/connection.php");
?>
<!DOCTYPE html>
<?php  
if(isset($_POST['login'])){
	$sname=$_POST['sname'];
	$exam=$_POST['exam'];
	if (empty($sname)) {
		echo "<script>alert('Enter Username')</script>";
		echo '<style><div class="alert alert-success ">you successfully loged in</div></style>';
	}
	elseif (empty($exam)) {
		echo "<script>alert('Enter your id')</script>";
	}
	else if(!empty($sname) && !empty($exam)){
		$query="SELECT * FROM patient WHERE username='$sname'";
		$res=mysqli_query($conn,$query);
		if(mysqli_num_rows($res)!=1){
			$_SESSION['exam']=$sname;
			echo "<script>alert('hi you login as student')</script>";
			header("Location:..patient/report.php");
			exit(); 
		}else{
			echo "<script>alert('Invalid credintials')</script>";
		}
	}
}
?>
<html>
<head>
	<title>Report Page</title>
</head>
<body>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-3"></div>
			<div class="col-md-6 my-5 jumbotron">
				 <h5 class="text-center my-3">Exam Login</h5>
				 <form action="" method="POST">
				 	<div class="form-group">
				 		<label>Patient Name</label>
				 		<input type="text" name="sname" class="form-control" autocomplete="off" placeholder="Enter Username">
				 	</div>
				 	<div class="form-group">
				 		<label>Patient Id</label>
				 		<input type="text" name="exam" class="form-control" autocomplete="off" placeholder="Enter Password">
				 	</div>
				 	<input type="submit" name="login" class="btn btn-success my-3"  value="Get">
				 </form>
			</div>
			<div class="col-md-3"></div>
		</div>
	</div>
</div>
</body>
</html>
