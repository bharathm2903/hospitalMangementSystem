<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Appointment</title>
</head>
<body>
<?php  
include("../login/header.php");
?>
<div class="container-fluid">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-2 " style="margin-left: -30px;">
			<?php
				include("../patient/sidenav.php");
				include("../login/connection.php");
			  ?>
		</div>
		<div class="col-md-10">
			<div class="col-md-12">
				<div class="row">
					<div class="col-md-6">
						<h5 class="text-center">All Appointment's</h5>
						<?php
						$query="SELECT * FROM information";
					$res=mysqli_query($conn,$query);
					if(mysqli_num_rows($res)==1){
						exit();
					}
					$output="
					
					<table class= 'table table-bordered'>
							<tr><th>Id</th>
							<th>Name</th>
							<th>Age</th>
							<th>Date</th>
							<th>Weight</th>
							<th>Height</th>
							<th>Cough</th>
							<th>Fever</th>
							<th>Headache</th>
							<th>Covid</th>
							<th>BP</th>
							<th>Blood suger</th>
							<th>Diabetes</th>
							<th>Cancer</th>
							<th>Death</th>
							<th>Pregnent</th>
							<th>Delivery</th>
							<th>Accident</th>
							<th>Smoking</th>
							<th>Heart disease</th>
							<th>Alcoholism</th>
							<th>Food poissoning</th>
							<th>Ulcer</th>
							<th>Kidney failure</th>
							<th>Asthma</th>
							<th>Skin disease</th>
							<th>Thrombosis</th>
							<th>Coma</th>
							<th>Cirrhosis</th>
							<th>Syphilis</th>
							<th>Rheumatoid</th>
							<th>Rabies</th>
							<th>Maleria</th>
							<th>Leukemia</th>
							<th>Appenditicities</th>
							<th>Jaundice</th>
							<th>Herpes</th>
							<th>Genitical candidiasis</th>
							<th>Diptheria</th>
							<th>Alzhemeier</th>
							<th>Cholora</th>
							<th>Chikunguniya</th>
							<th>Anaemia</th>
							<th>Habatities</th>
							<th>Chronic disease</th>
							<th>Tuberclosis</th>
							<th>Lipid disorder</th>
							<th>Patch</th>
							<th>Snewsing</th>
							<th>Hyper tension</th>
							<th>HIV</th>
							<th>Injury or violence</th>
							<th>Mendal health</th>
							<th>FLU or pneumonia</th>
							<th>Cataract</th>
							<th style='width: 10%';>Status</th>
					</tr>";
					while ($row=mysqli_fetch_assoc($res)){
						$id=$row['id'];
						$name=$row['name'];
						$age=$row['age'];
						$date=$row['date'];
						$weight=$row['weight'];
						$height=$row['height'];
						$cancer=$row['history of cancer'];
						$death=$row['death'];
						$pregnent=$row['pregnent'];
						$covid=$row['covid'];
						$alcohol=$row['alcoholism'];
						$head=$row['headache'];
						$food=$row['food poissoning'];
						$thro=$row['thrombosis'];
						$cough=$row['cough'];
						$coma=$row['coma'];
						$cir=$row['cirrhosis'];
						$sypi=$row['sypilis'];
						$rhe=$row['rheumatoid'];
						$rab=$row['rabies'];
						$mal=$row['maleria'];
						$kid=$row['kidney stone'];
						$app=$row['appenditicities'];
						$leu=$row['leukemia'];
						$jan=$row['jaundice'];
						$her=$row['herpes'];
						$gen=$row['genitical candidiasis'];
						$dip=$row['diptheria'];
						$alz=$row['alzhemeier disease'];
						$cho=$row['cholora'];
						$chi=$row['chikunguniya'];
						$ul=$row['ulcer'];
						$smo=$row['smoking or tobacco'];
						$ane=$row['anaemia'];
						$dia=$row['diabetes'];
						$heart=$row['heart disease'];
						$fail=$row['kidney failure'];
						$hab=$row['habatities'];
						$as=$row['asthma'];
						$chro=$row['chronic disease'];
						$tub=$row['tuberclosis'];
						$lip=$row['lipid disorder'];
						$pat=$row['patch'];
						$snew=$row['snewsing'];
						$fever=$row['fever'];
						$ht=$row['hyper tension'];
						$hiv=$row['hiv'];
						$vio=$row['injury or violence'];
						$men=$row['mendal health'];
						$flu=$row['flu or pneumonia'];
						$cat=$row['cataract'];
						$skin=$row['skin disease'];
						$acc=$row['accident'];
						$suger=$row['sugar'];
						$delivery=$row['Delivery'];
						$bp=$row['Bp'];
						$output.="
						<tr>
								<td>$id</td>
								<td>$name</td>
								<td>$age</td>
								<td>$date</td>
								<td>$weight</td>
								<td>$height</td>
								<td>$cough</td>
								<td>$fever</td>
								<td>$head</td>
								<td>$covid</td>
								<td>$bp</td>
								<td>$suger</td>
								<td>$dia</td>
								<td>$cancer</td>
								<td>$death</td>
								<td>$pregnent</td>
								<td>delivery</td>
								<td>$acc</td>
								<td>$smo</td>
								<td>$heart</td>
								<td>$alcohol</td>
								<td>$food</td>
								<td>$fail</td>
								<td>$as</td>
								<td>$skin</td>
								<td>$thro</td>
								<td>$coma</td>
								<td>$cir</td>
								<td>$sypi</td>
								<td>$rhe</td>
								<td>$rab</td>
								<td>$mal</td>
								<td>$leu</td>
								<td>$app</td>
								<td>$jan</td>
								<td>$her</td>
								<td>$gen</td>
								<td>$dip</td>
								<td>$alz</td>
								<td>$cho</td>
								<td>$chi</td>
								<td>$ane</td>
								<td>$hab</td>
								<td>$chro</td>
								<td>$tub</td>
								<td>$lip</td>
								<td>$pat</td>
								<td>$snew</td>
								<td>$ht</td>
								<td>$hiv</td>
								<td>$vio</td>
								<td>$men</td>
								<td>$flu</td>
								<td>$cat</td>
						";
					}
					$output.="<tr></tr>
						</table>";
					echo "$output";
						?>

					</div>
					<div class="col-md-6">
						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>