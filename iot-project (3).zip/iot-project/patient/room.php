<?php 
 session_start();
 include("../login/header.php");
include("../login/connection.php");
 ?>
 <!DOCTYPE html>
 <html>
 <head>
 	<title>Patient Data</title>
 </head>
 <body>
 <div style="margin-top: 80px"></div>
<div class="container" style="height:100px">
	<div class="col-md-12">
		<div class="row">
		<div class="col-md-3"></div>
		<div class="col-md-6 jumbotron">
			<form method="post" class="my-2">
				<div class="text-center" style="font-size: 30px">Out Patient Case</div>
				<div class="form-group">
					<label>Patient name</label>
					<input type="text" name="pname" class="form-control" autocomplete="off" placeholder="Enter Username">
				</div>
				<div class="form-group">
					<label>Guardian Name</label>
					<input type="password" name="gname" class="form-control" autocomplete="off" placeholder="Enter Guardian name">
				</div>
				<div class="form-group">
					<label>Room No</label>
					<input type="number" name="room" class="form-control" autocomplete="off" placeholder="Enter the Room Number">
				</div>
				<div class="form-group">
					<label class="alert alert-danger">Symptoms</label><br>
					<label>Fever</label>
					<input type="checkbox" name="health issue"><br>
					<label>Cold</label>
					<input type="checkbox" name="health issue"><br>
					<label>Heart patient</label>
					<input type="checkbox" name="health issue"><br>
					<label>Pressure</label>
					<input type="checkbox" name="health issue"><br>
					<label>Leg pain</label>
					<input type="checkbox" name="health issue"><br>
					<label></label>
					<input type="checkbox" name="health issue">
				</div>
					<div class="form-group">
					<label>Problem</label>
					<input type="text" name="pro" class="form-control" autocomplete="off" placeholder="Enter Health Issue">
				</div>
				<div class="form-group">
					<a href="#"></a>
				<input type="submit" name="login" class="btn btn-success" value="Normal check-up"><input type="submit" name="log1" class="btn btn-info" value="Normal Ward"><input type="submit" name="log" class="btn btn-danger" value="ICU"></div>
			</form>
		</div>
		<div class="col-md-3"></div>
	</div>
	</div>
</div>
<?php
if(isset($_POST['login']) || isset($_POST['log1']) || isset($_POST['log'])) {
	$pname=$_POST['pname'];
$room=$_POST['room'];
$pro=$_POST['pro'];
$sql="INSERT INTO `patient1`(`id`, `patient  name`, `room`, `probem`) VALUES ('','$pname','$room','$pro')";	
$res=mysqli_query($conn,$sql);
if($res){
	echo "<script>alert('patient details successfully submitted')</script>";
}
else{
	echo "<script>alert('patient details not submitted')</script>";
}
}


?>
 </body>
 </html>